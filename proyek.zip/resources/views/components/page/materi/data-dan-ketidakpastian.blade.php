<x-layouts.app>
    <x-slot:title>
        Pembahasan Bilangan | E-numerasi
    </x-slot:title>

    <div class="bg-sky-50 min-h-screen">
        <div class="container mx-auto px-6 py-10">

            {{-- HEADER --}}
            <header class="mb-12 text-center">
                <h1 class="text-4xl md:text-5xl font-extrabold text-sky-600 tracking-tight">
                    Pembahasan dan Contoh Soal — Materi Bilangan
                </h1>
                <p class="mt-3 text-lg text-sky-900/80 max-w-3xl mx-auto leading-relaxed">
                    Kumpulan contoh soal pemahaman, penerapan, dan penalaran lengkap dengan pembahasan.
                </p>
            </header>

            <main class="space-y-16">

                {{-- A. Contoh Soal Pemahaman --}}
                <section>
                    <h2
                        class="text-2xl md:text-3xl font-bold text-sky-700 flex items-center gap-3 border-b-4 border-sky-400 pb-2 mb-6">
                        <span class="bg-sky-100 text-sky-600 px-3 py-1 rounded-lg">A</span>
                        Contoh Soal Pemahaman
                    </h2>

                    <article class="bg-white rounded-2xl border border-sky-100 shadow-md overflow-hidden">
                        <div class="p-6">
                            <h3 class="text-xl font-bold text-sky-800 mb-3">Perhatikan Garis Bilangan Berikut.</h3>

                            <img src="{{ asset('images/garisbilangan.png') }}" alt="">

                            <p class="text-sky-900/90 leading-relaxed text-xl mt-2 mb-4">
                                Bilangan <span class="font-semibold">A</span> yang memenuhi adalah …
                            </p>

                            <ul class="grid sm:grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                                <li class="bg-sky-50 border border-sky-100 rounded-lg px-3 py-2">32,3</li>
                                <li
                                    class="bg-sky-50 border border-sky-100 rounded-lg px-3 py-2 font-semibold text-sky-700">
                                    32,6 <span class="font-bold"> Jawaban Benar</span></li>
                                <li class="bg-sky-50 border border-sky-100 rounded-lg px-3 py-2">33,2</li>
                                <li class="bg-sky-50 border border-sky-100 rounded-lg px-3 py-2">33,4</li>
                            </ul>

                            <div class="bg-sky-50 border-l-4 text-xl border-sky-400 p-4 rounded-r-xl">
                                <div class="font-semibold text-sky-800">Pembahasan</div>
                                <p class="text-sky-900/90">
                                    Perhatikan bahwa antara bilangan 32 dan 33 dibagi menjadi 5 bagian, sehingga setiap 1 bagian bernilai
                                    <span class="font-mono">\[\frac{1}{5}=0,2\]</span>.
                                    Bilangan A berada 3 langkah dari bilangan 32, sehingga nilainya:
                                    <span class="font-mono">32 + 3 × 0,2 = 32 + 0,6 = 32,6</span>.
                                </p>
                                <p
                                    class="inline-flex items-center rounded-md bg-sky-400/10 px-2 text-lg py-1 mt-4 font-medium text-slate-700 inset-ring inset-ring-sky-400/30">
                                    Jawaban: 32,6
                                </p>
                            </div>
                        </div>
                    </article>

                    <article class="bg-white rounded-2xl border border-sky-100 shadow-md overflow-hidden mt-8">
                        <div class="p-6">
                            <h3 class="text-xl font-bold text-sky-800 mb-3">Manajemen Waktu Nani</h3>
                            <p class="text-sky-900/90 text-xl leading-relaxed mb-4">
                                Dalam satu hari, Nani menggunakan,
                                <span class="font-mono">\[\dfrac{1}{4}\]</span> waktunya untuk tidur,
                                <span class="font-mono">\[\dfrac{1}{3}\]</span> untuk sekolah,
                                <span class="font-mono">\[\dfrac{1}{8}\]</span> untuk makan dan belajar.
                                Sisanya untuk bermain, menonton TV, dan membantu orang tua.
                            </p>

                            <div class="overflow-x-auto shadow-md mb-4">
                                <table class="min-w-[560px] w-full text-xl text-left border-collapse">
                                    <thead>
                                        <tr class="bg-sky-600 text-white">
                                            <th class="py-3 px-4 rounded-tl-xl">Pernyataan</th>
                                            <th class="py-3 px-4">Benar</th>
                                            <th class="py-3 px-4 rounded-tr-xl">Salah</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-sky-900/90">
                                        <tr class="border-b border-sky-100">
                                            <td class="py-3 px-4">Nani menghabiskan waktu terbanyak untuk tidur.</td>
                                            <td class="py-3 px-4">❌</td>
                                            <td class="py-3 px-4">✅</td>
                                        </tr>
                                        <tr class="border-b border-sky-100">
                                            <td class="py-3 px-4">Selama 8 jam, Nani menghabiskan waktunya belajar di sekolah.</td>
                                            <td class="py-3 px-4">✅</td>
                                            <td class="py-3 px-4">❌</td>
                                        </tr>
                                        <tr>
                                            <td class="py-3 px-4">Bermain, menonton TV, dan membantu orang tua dilakukan selama 7 jam.</td>
                                            <td class="py-3 px-4">✅</td>
                                            <td class="py-3 px-4">❌</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                            <div class="bg-sky-50 border-l-4 text-sky-800 text-xl border-sky-400 p-4 rounded-r-xl mt-4">
                                <div class="font-semibold">Pembahasan</div>
                                <p>Dalam satu hari terdapat 24 jam.</p>
                                <p>\[\tfrac{1}{4}\times 24 = 6\] jam untuk tidur.</p>
                                <p>\[\tfrac{1}{3}\times 24 = 8\] jam untuk sekolah.</p>
                                <p>\[\tfrac{1}{8}\times 24 = 3\] jam untuk makan & belajar.</p>
                                <p>Sisa = 24 – 6 – 8 – 3 = 7 jam untuk aktivitas lain.</p>
                            </div>
                        </div>
                    </article>
                </section>

                {{-- B. Contoh Soal Penerapan --}}
                <section>
                    <h2
                        class="text-2xl md:text-3xl font-bold text-sky-700 flex items-center gap-3 border-b-4 border-sky-400 pb-2 mb-6">
                        <span class="bg-sky-100 text-sky-600 px-3 py-1 rounded-lg">B</span>
                        Contoh Soal Penerapan
                    </h2>

                    <article class="bg-white rounded-2xl border border-sky-100 shadow-md overflow-hidden">
                        <div class="p-6">
                            <h3 class="text-xl font-bold mb-3">Seorang pekerja bangunan</h3>
                            <p class="text-sky-900/90 leading-relaxed text-xl mb-4">
                                Seorang pekerja memotong \(\tfrac{1}{5}\) bagian pipa sepanjang 3 m.
                                Panjang pipa mula-mula adalah...
                            </p>
                            <ul class="grid sm:grid-cols-2 md:grid-cols-4 gap-3 mb-4 text-sky-800 text-xl">
                                <li class="bg-sky-50 border border-sky-100 rounded-lg px-3 py-2">8 m</li>
                                <li class="bg-sky-50 border border-sky-100 rounded-lg px-3 py-2">12 m</li>
                                <li class="bg-sky-50 border border-sky-100 rounded-lg px-3 py-2 font-semibold text-sky-700">15 m<span class="italic"> (Benar)</span></li>
                                <li class="bg-sky-50 border border-sky-100 rounded-lg px-3 py-2">18 m</li>
                            </ul>
                            <div class="bg-sky-50 border-l-4 text-sky-900/90 text-xl border-sky-400 p-4 rounded-r-xl">
                                <div class="font-semibold text-sky-800">Pembahasan</div>
                                <p>\(\tfrac{1}{5}L = 3 \Rightarrow L=15\).</p>
                            </div>
                        </div>
                    </article>
                </section>

                {{-- C. Contoh Soal Penalaran --}}
                <section>
                    <h2
                        class="text-2xl md:text-3xl font-bold text-sky-700 flex items-center gap-3 border-b-4 border-sky-400 pb-2 mb-6">
                        <span class="bg-sky-100 text-sky-600 px-3 py-1 rounded-lg">C</span>
                        Contoh Soal Penalaran
                    </h2>

                    <article class="bg-white rounded-2xl border border-sky-100 shadow-md overflow-hidden">
                        <div class="p-6">
                            <h3 class="text-xl font-bold mb-3">Menentukan Bilangan</h3>
                            <p class="text-sky-900/90 text-xl leading-relaxed mb-4">
                                Bilangan A = 8,6, dst...
                            </p>
                            <div class="bg-sky-50 border-l-4 text-sky-900/90 border-sky-400 p-4 rounded-r-xl mt-4">
                                <div class="font-semibold text-sky-800">Pembahasan</div>
                                <p>Semua perhitungan → hasil urutan bilangan ditulis dengan tema sky.</p>
                            </div>
                        </div>
                    </article>
                </section>

                {{-- CTA --}}
                <section class="text-center py-10">
                    <div class="bg-gradient-to-br from-sky-400 to-sky-600 rounded-2xl p-8 text-white shadow-2xl shadow-sky-200">
                        <h2 class="text-3xl font-bold mb-3">Sudah paham?</h2>
                        <p class="mb-6 max-w-2xl mx-auto">Yuk coba soal berikut.</p>
                        <a href="{{ route('materi-bilangan-soal') }}"
                           class="inline-block bg-white text-sky-700 font-bold text-lg py-3 px-8 rounded-xl shadow-md hover:bg-sky-50 transform hover:-translate-y-0.5 transition">
                            Coba Soal
                        </a>
                    </div>
                </section>

            </main>
        </div>
    </div>
</x-layouts.app>
