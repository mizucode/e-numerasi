<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        E-numerasi:Home
     <?php $__env->endSlot(); ?>

<div class="bg-white/90">
        <div class="container mx-auto px-6 py-12">
            <header class="mb-12 text-center">
                <h1 class="text-5xl font-extrabold text-sky-700 tracking-tight">Materi Lengkap: Aljabar</h1>
                <p class="mt-4 text-lg text-gray-600">Ringkasan konsep, rumus, dan contoh soal.</p>
            </header>

            <main class="space-y-16">

                <section>
                    <h2 class="text-3xl font-bold text-gray-800 border-b-4 border-sky-400 pb-2 mb-6">Pola Barisan Bilangan</h2>
                    <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                        <div class="bg-gray-50 p-6 rounded-lg shadow-md">
                            <h3 class="font-semibold text-xl text-sky-800 mb-3">Pola Bilangan Persegi Panjang</h3>
                            <p class="text-gray-600 mb-2">Barisan: 2, 6, 12, 20, ...</p>
                            <p class="text-gray-700 font-medium">Rumus Suku ke-n:</p>
                            <code class="block bg-gray-200 text-gray-800 p-2 rounded-md mt-1 font-mono text-center text-lg">Un = n(n + 1)</code>
                        </div>
                        <div class="bg-gray-50 p-6 rounded-lg shadow-md">
                            <h3 class="font-semibold text-xl text-sky-800 mb-3">Pola Bilangan Persegi</h3>
                            <p class="text-gray-600 mb-2">Barisan: 1, 4, 9, 16, ...</p>
                            <p class="text-gray-700 font-medium">Rumus Suku ke-n:</p>
                            <code class="block bg-gray-200 text-gray-800 p-2 rounded-md mt-1 font-mono text-center text-lg">Un = n²</code>
                        </div>
                        <div class="bg-gray-50 p-6 rounded-lg shadow-md">
                            <h3 class="font-semibold text-xl text-sky-800 mb-3">Pola Bilangan Segitiga</h3>
                            <p class="text-gray-600 mb-2">Barisan: 1, 3, 6, 10, ...</p>
                            <p class="text-gray-700 font-medium">Rumus Suku ke-n:</p>
                            <code class="block bg-gray-200 text-gray-800 p-2 rounded-md mt-1 font-mono text-center text-lg">Un = n(n + 1) / 2</code>
                        </div>
                        <div class="bg-gray-50 p-6 rounded-lg shadow-md">
                            <h3 class="font-semibold text-xl text-sky-800 mb-3">Pola Bilangan Ganjil</h3>
                            <p class="text-gray-600 mb-2">Barisan: 1, 3, 5, 7, 9, ...</p>
                            <p class="text-gray-700 font-medium">Rumus Suku ke-n:</p>
                            <code class="block bg-gray-200 text-gray-800 p-2 rounded-md mt-1 font-mono text-center text-lg">Un = 2n - 1</code>
                        </div>
                        <div class="bg-gray-50 p-6 rounded-lg shadow-md">
                            <h3 class="font-semibold text-xl text-sky-800 mb-3">Pola Bilangan Genap</h3>
                            <p class="text-gray-600 mb-2">Barisan: 2, 4, 6, 8, 10, ...</p>
                            <p class="text-gray-700 font-medium">Rumus Suku ke-n:</p>
                            <code class="block bg-gray-200 text-gray-800 p-2 rounded-md mt-1 font-mono text-center text-lg">Un = 2n</code>
                        </div>
                        <div class="bg-gray-50 p-6 rounded-lg shadow-md">
                            <h3 class="font-semibold text-xl text-sky-800 mb-3">Pola Segitiga Pascal</h3>
                            <p class="text-gray-600">Digunakan untuk menentukan koefisien pada suku banyak $$(a+b)^n$$.</p>
                        </div>
                    </div>
                </section>

                <section>
                    <h2 class="text-3xl font-bold text-gray-800 border-b-4 border-sky-400 pb-2 mb-6">Barisan dan Deret</h2>
                    <div class="space-y-8">
                        <div class="bg-white border border-gray-200 p-6 rounded-lg">
                            <h3 class="text-2xl font-semibold text-sky-800 mb-3">Aritmetika</h3>
                            <p class="mb-4 text-gray-600">Barisan yang setiap sukunya memiliki beda (selisih) yang tetap.</p>
                            <p class="font-medium">Suku ke-n (Un): <code class="bg-gray-200 p-1 rounded">Un = a + (n - 1)b</code></p>
                            <p class="font-medium mt-2">Jumlah n Suku Pertama (Sn): <code class="bg-gray-200 p-1 rounded">Sn = n/2 (a + Un)</code> atau <code class="bg-gray-200 p-1 rounded">Sn = n/2 (2a + (n - 1)b)</code></p>
                        </div>

                        <div class="bg-white border border-gray-200 p-6 rounded-lg">
                            <h3 class="text-2xl font-semibold text-sky-800 mb-3">Geometri</h3>
                            <p class="mb-4 text-gray-600">Barisan yang setiap sukunya memiliki rasio (faktor pengali) yang tetap.</p>
                            <p class="font-medium">Suku ke-n (Un): <code class="bg-gray-200 p-1 rounded">Un = ar^(n-1)</code></p>
                             <p class="font-medium mt-2">Jumlah n Suku Pertama (Sn):</p>
                             <ul class="list-disc list-inside text-gray-700 mt-2">
                                <li>Jika r < 1: <code class="bg-gray-200 p-1 rounded">Sn = a(1 - r^n) / (1 - r)</code></li>
                                <li>Jika r > 1: <code class="bg-gray-200 p-1 rounded">Sn = a(r^n - 1) / (r - 1)</code></li>
                             </ul>
                        </div>
                    </div>
                </section>
                
                <section>
                    <h2 class="text-3xl font-bold text-gray-800 border-b-4 border-sky-400 pb-2 mb-6">Aritmetika Sosial</h2>
                     <div class="space-y-4 text-gray-700">
                        <p><strong>Untung:</strong> Harga Jual > Harga Beli. Persentase Untung = (Untung / Harga Beli) x 100%.</p>
                        <p><strong>Rugi:</strong> Harga Jual < Harga Beli. Persentase Rugi = (Rugi / Harga Beli) x 100%.</p>
                        <p><strong>Bruto, Netto, Tara:</strong> Bruto (berat kotor) = Netto (berat bersih) + Tara (berat kemasan).</p>
                        <p><strong>Diskon:</strong> Potongan harga. Harga Akhir = Harga Awal - (Diskon % x Harga Awal).</p>
                        <p><strong>Bunga Tunggal:</strong> Bunga 1 Tahun = Persentase Bunga x Modal Awal.</p>
                     </div>
                </section>

                <section>
                    <h2 class="text-3xl font-bold text-gray-800 border-b-4 border-sky-400 pb-2 mb-6">Persamaan dan Pertidaksamaan</h2>
                    <div class="grid md:grid-cols-2 gap-8">
                        <div class="bg-white border border-gray-200 p-6 rounded-lg">
                             <h3 class="text-2xl font-semibold text-sky-800 mb-3">Persamaan Linier Satu Variabel (PLSV)</h3>
                             <p class="text-gray-600 mb-3">Aturan: Kedua ruas boleh ditambah, dikurang, dikali, atau dibagi dengan bilangan yang sama (selain nol).</p>
                             <p class="font-semibold">Contoh: 2n + 8 = 30</p>
                             <p>2n = 30 - 8  &rarr;  2n = 22  &rarr;  n = 11</p>
                        </div>
                        <div class="bg-white border border-gray-200 p-6 rounded-lg">
                            <h3 class="text-2xl font-semibold text-sky-800 mb-3">Pertidaksamaan Linier Satu Variabel (PtLSV)</h3>
                            <p class="text-gray-600 mb-3">Aturan: Sama seperti PLSV, namun jika kedua ruas dikali/dibagi bilangan negatif, tanda pertidaksamaan (<, >, ≤, ≥) harus dibalik.</p>
                            <p class="font-semibold">Contoh: -1/2 y < 4</p>
                             <p>(-2) * (-1/2 y) > 4 * (-2)  &rarr;  y > -8</p>
                        </div>
                    </div>
                </section>
                
                <section>
                    <h2 class="text-3xl font-bold text-gray-800 border-b-4 border-sky-400 pb-2 mb-6">Sistem Persamaan Linear Dua Variabel (SPLDV)</h2>
                    <p class="text-gray-600 mb-4">Dua persamaan linear dengan dua variabel (misal x dan y) yang saling berhubungan. Bentuk umum: ax + by = c dan px + qy = r.</p>
                    <h3 class="text-xl font-semibold text-sky-800 mb-3">Metode Penyelesaian:</h3>
                    <div class="space-y-4">
                        <p><strong>1. Substitusi:</strong> Menggantikan satu variabel dari satu persamaan ke persamaan lainnya.</p>
                        <p><strong>2. Eliminasi:</strong> Menghilangkan salah satu variabel dengan menyamakan koefisiennya lalu menambah atau mengurangkan kedua persamaan.</p>
                        <p><strong>3. Grafik:</strong> Mencari titik potong dari kedua garis persamaan pada grafik Kartesius.</p>
                    </div>
                </section>

                <section>
                    <h2 class="text-3xl font-bold text-gray-800 border-b-4 border-sky-400 pb-2 mb-6">Contoh Soal dan Pembahasan</h2>
                    <div class="space-y-8">
                        <div class="bg-blue-50 border-l-4 border-blue-500 p-6 rounded-r-lg">
                            <h3 class="font-bold text-xl text-blue-900">Soal 1: Diskon Burger</h3>
                            <p class="mt-2 text-gray-700">Sebuah burger dengan harga awal Rp30.000,00 dijual dengan harga promo Rp22.500,00. Berapa persen diskon yang ditawarkan?</p>
                            <div class="mt-4 bg-white p-4 rounded">
                                <p><strong class="font-semibold">Pembahasan:</strong></p>
                                <p>Diskon = Rp30.000 - Rp22.500 = Rp7.500</p>
                                <p>Persentase Diskon = (7.500 / 30.000) x 100% = 25%.</p>
                                <p class="font-bold text-blue-800 mt-2">Jawaban: 25%</p>
                            </div>
                        </div>

                        <div class="bg-green-50 border-l-4 border-green-500 p-6 rounded-r-lg">
                            <h3 class="font-bold text-xl text-green-900">Soal 2: Belanja Cerdas</h3>
                            <p class="mt-2 text-gray-700">Bu Andin ingin membeli 2 baju yang sama. Di toko mana ia harus membeli agar pengeluarannya minimal?</p>
                            <ul class="list-disc list-inside pl-4 mt-2 text-gray-600">
                                <li><strong>Toko Riang:</strong> Beli 1 Gratis 1</li>
                                <li><strong>Toko Gembira:</strong> Diskon 50% + 20%</li>
                                <li><strong>Toko Ceria:</strong> Diskon 40%</li>
                                <li><strong>Toko Bahagia:</strong> Diskon 90% untuk pembelian ke-2</li>
                            </ul>
                            <div class="mt-4 bg-white p-4 rounded">
                                <p><strong class="font-semibold">Pembahasan:</strong></p>
                                <p>Toko Riang (Beli 1 Gratis 1) = Diskon 50%</p>
                                <p>Toko Gembira (50% + 20%) = Diskon 50% + (20% dari sisa 50%) = 50% + 10% = Diskon 60%</p>
                                <p>Toko Ceria = Diskon 40%</p>
                                <p>Toko Bahagia (0% + 90%)/2 = Diskon 45%</p>
                                <p class="font-bold text-green-800 mt-2">Jawaban: Di Toko Gembira, karena memberikan diskon efektif terbesar.</p>
                            </div>
                        </div>
                    </div>
                </section>
            </main>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH D:\WEB APP\e-numerasi\proyek\resources\views/components/page/materi.blade.php ENDPATH**/ ?>